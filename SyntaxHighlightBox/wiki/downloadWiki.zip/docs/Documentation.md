# Using the SyntaxHighlightBox

Instantiate your component as you are used to.
{code:xml}
<shbox:SyntaxHighlightBox IsLineNumbersMarginVisible="True" x:Name="shbox" />
{code:xml}

Set the highlighter to the required syntax language file in code-behind.
{code:c#}
shbox.CurrentHighlighter = HighlighterManager.Instance.Highlighters["VHDL"](_VHDL_);
{code:c#}


# Creating a new syntax definition file

You will need the source code of the application (I'm planning a release where definitions can be stored as content files).
Add your .xml definitions to the **resources** folder, and ensure that they are built as **Resources**. That's all, the HighlighterManager will handle the file for you.

Just have a look at the provided definition file to understand its syntax, its simple enough.

**Note**: All xml elements are required on each rule. This means that IgnoreCase, Foreground, FontWeight, etc. MUST be provided on each rule.

Rule precedence:
* First, word rules are applied
* Then, advanced rules are applied (if any)
* Finally, line rules are applied, overriding any present style

{code:xml}
<?xml version="1.0" encoding="utf-8" ?>

<!-- Very important: "name" attribute defines the syntax name that will be used by the HighlihterManager -->
<Syntax name="MyNewSyntax">
	<!-- Words rules will only highlight the provided words -->
	<HighlightWordsRule name="Blue words">
		<Words>
			blue ocean water ice air
			aqua cold sky
		</Words>
		<IgnoreCase>true</IgnoreCase>
		<Foreground>#0000FF</Foreground>
		<FontWeight>Bold</FontWeight>
		<FontStyle>Normal</FontStyle>
	</HighlightWordsRule>

	<!-- Line rules will highlight the LineStart token as well as the rest of the line -->
	<HighlightLineRule name="Comments">
		<LineStart>//</LineStart>
		<IgnoreCase>false</IgnoreCase>
		<Foreground>#00FF00</Foreground>
		<FontWeight>Normal</FontWeight>
		<FontStyle>Normal</FontStyle>
	</HighlightLineRule>

	<!-- Advanced rules use a regular expression to find what they must highlight -->
	<!-- Do not overuse them, as they have a great computer time cost --> 
	<AdvancedHighlightRule name="Numbers">
		<Expression>\b([0-9](0-9)+)\b</Expression>
		<IgnoreCase>false</IgnoreCase>
		<Foreground>#F68A1B</Foreground>
		<FontWeight>Normal</FontWeight>
		<FontStyle>Normal</FontStyle>
	</AdvancedHighlightRule>
</Syntax>

{code:xml}

# Create a true custom highlighter

Xml-based highlighters are ok for simple definition files, but regular-expression matching can have a great impact on performances. This is why you can just implement your own Highlighter, by overriding the IHighlighter interface.
The **int Highlight(FormattedText, int)** allows you to change the formatting of FormattedText blocks. Be aware that certain highlight rules can span on several blocks (like the block comments in C++), so you will need to use the "previous code" given as second argument to know how was highlighted the end of the previous block (this is a custom way of doing things, so you will need to use your own implementation of codes, defined as integers).